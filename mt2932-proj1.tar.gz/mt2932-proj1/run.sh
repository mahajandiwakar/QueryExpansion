#!/bin/bash   
java -cp ./commons-codec-1.10.jar:./json-simple-1.1.1.jar:.  BingTest 6ogFrWjyeWmPufqcZFqcmTMvJDxvznvQIwGYXDwvZQo $1 $2
