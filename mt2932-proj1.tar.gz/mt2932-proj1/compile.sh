#!/bin/bash   
javac -cp ./commons-codec-1.10.jar:./json-simple-1.1.1.jar:.  BingTest.java SearchResults.java ResultElement.java AugmentQuery.java InvertedIndex.java VectorElem.java DocVector.java IndexElem.java
